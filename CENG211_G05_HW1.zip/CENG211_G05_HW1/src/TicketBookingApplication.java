import java.util.Random;

public class TicketBookingApplication {

    public static void main(String[] args) {
        // Mekanı ve bölümleri oluşturuyoruz
        Venue venue = new Venue();

        // Dosya yolunu belirtiyoruz (gerçek dosya yolunu değiştirin)
        String filePath = "customers.csv";
        
        // Müşteri verilerini dosyadan okuyoruz
        FileIO fileIO = new FileIO();
        fileIO.getData(filePath);
        Customer[] customers = fileIO.getCustomers();

        // Müşterilerin bilet rezervasyonları
        Random random = new Random();
        for (Customer customer : customers) {
            for (int i = 0; i < customer.getBookedTickets().length; i++) {
                // Rastgele bir bölüm, sıra ve koltuk seçiyoruz
                int randomSection = random.nextInt(venue.getSections().length);
                int randomRow = random.nextInt(venue.getSection(randomSection).getNumRows());
                int randomSeat = random.nextInt(venue.getSection(randomSection).getNumSeatsPerRow());

                // Müşteri için rastgele bilet rezerve ediyoruz
                customer.bookTicket(venue.getSection(randomSection).getTicket(randomRow, randomSeat), i);
            }
        }

        // Sorguların çalıştırılması ve sonuçların ekrana yazdırılması
        System.out.println("=== Highest Revenue Section ===");
        Query.highestRevenueSection(venue);

        System.out.println("\n=== Total Venue Revenue ===");
        Query.totalVenueRevenue(venue);

        System.out.println("\n=== Venue Occupancy Rate ===");
        Query.occupancyRate(venue);

        System.out.println("\n=== Customer with Highest Total ===");
        Query.customerWithHighestTotal(customers);

        System.out.println("\n=== Most Expensive Ticket ===");
        Query.mostExpensiveTicket(venue);

        System.out.println("\n=== Seat Occupancies ===");
        Query.displayOccupancy(venue);
    }
}
